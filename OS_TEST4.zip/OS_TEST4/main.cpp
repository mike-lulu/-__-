#include"file_system.h"
#include"memory_management.h"
#include"process_dispatch.h"

void File_menu();
void Memory_menu();
void Process_menu();
int ff = 0;//����ڴ����
//�ļ�����
void File_menu()
{
	char command[100];
	int flag;
	char way[100];
	char cway[100];
	while(1)
	{
		printf("%s:>",path);
		scanf("%s",command);
		if(strcmp(command,"exit") == 0)
			break;
		if(strcmp(command,"dir") != 0 && strcmp(command,"help") != 0)
			scanf("%s",way);
		if(strcmp(command,"copy") == 0)
		{
			scanf("%s",cway);
			Is_copy = 1;
		}
		else
			Is_copy = 0;
		flag = order(command);
		switch(flag)
		{
		case 1:
			Make_Dir(way);
			break;
		case 2:
			Delete_Dir(way);
			break;
		case 3:
			Change_Dir(way);
			break;
		case 4:
			Show_Dir();
			break;
		case 5:
			Create_File(way);
			break;
		case 6:
			Show_Content_File(way);
			break;
		case 7:
			Change_Property_File(way);
			break;
		case 8:
			Close_File(way);
			break;
		case 9:
			Open_File(way);
			break;
		case 10:
			Read_File(way);
			break;
		case 11:
			Write_File(way);
			break;
		case 12:
			Delete_File(way);
			break;
		case 13:
			Copy_File(way,cway);
			break;
		case 14:
			Help();
			break;
		default:
			printf("�������!������help��ȡ����\n");
			break;
		}
	}
}
//�ڴ����
void Memory_menu()
{
	int flag = 1;
	int slect;
	if(ff == 0)
	{
		CreateMemory();
		InitProcess(&process);
		CreateProcess();
		ApplyMemory();
		system("cls");
	}
	while(flag)
	{
		printf("\t\t\t 1.�����ڴ�\n");
		printf("\t\t\t 2.�����ڴ�\n");
		printf("\t\t\t 3.��ʾ�ڴ���Ϣ\n");
		printf("\t\t\t 4.��ʾ����ҳ����Ϣ\n");
		printf("\t\t\t 5.��ַת��\n");
		printf("\t\t\t 6.�˳�\n");
		printf("��ѡ��:");
		scanf("%d",&slect);
		switch(slect)
		{
		case 1:
			system("cls");
			Apply();
			break;
		case 2:
			system("cls");
			Recycle();
			break;
		case 3:
			system("cls");
			PrintMemory();
			break;
		case 4:
			system("cls");
			PrintProcessSegment();
			break;
		case 5:
			system("cls");
			AddressExchange();
			break;
		case 6:
			flag = 0;
			break;
		default:
			printf("�������,������ѡ��!\n");
			break;
		}
	}
}
//���̵���
void Process_menu()
{
	int i = 0;
	PCB *r;
	r = process->next;
	printf("��ѡ����ȷ���:\n1:FCFS 2: PRIORITY\n");
	scanf("%d",&i);
	if(!r)
	{
		free(process);
		switch(i)
		{
		case 1:
			flag = 1;
			CreateList(pcb_ready);
			Show_State(pcb_ready,pcb_running,pcb_finished);
			printf("\n��ʼ����:\n");
			Dispatch_FCFS(pcb_ready,pcb_running,pcb_finished);
			Show_State(pcb_ready,pcb_running,pcb_finished);
			break;
		case 2:
			flag = 2;
			CreateList(pcb_ready);
			Show_State(pcb_ready,pcb_running,pcb_finished);
			printf("\n��ʼ����:\n");
			Dispatch_PRI(pcb_ready,pcb_running,pcb_finished);
			Show_State(pcb_ready,pcb_running,pcb_finished);
			break;
		default:
			break;
		}
		free(pcb_running);
	    free(pcb_ready);
    	free(pcb_finished);
    	ff = 0;
	}
	else
	{
		switch(i)
		{
		case 1:
			flag = 1;
			CreateList(process);
			Show_State(process,pcb_running,pcb_finished);
			printf("\n��ʼ����:\n");
			Dispatch_FCFS(process,pcb_running,pcb_finished);
			Show_State(process,pcb_running,pcb_finished);
			break;
		case 2:
			flag = 2;
			CreateList(process);
			Show_State(process,pcb_running,pcb_finished);
			printf("\n��ʼ����:\n");
			Dispatch_PRI(process,pcb_running,pcb_finished);
			Show_State(process,pcb_running,pcb_finished);
			break;
		default:
			break;
		}
		free(pcb_running);
	    free(process);
    	free(pcb_finished);
	    ff = 0;
	}
}

int main()
{
	InitDir();
	InitFAT();
	InitInfo_t();
	int slect;
	int flag = 1;
	while(flag)
	{
		printf("\t\t\t 1�����̵���\n");
		printf("\t\t\t 2���ڴ����\n");
		printf("\t\t\t 3���ļ�����\n");
		printf("\t\t\t 4���˳�\n");
		printf("��ѡ��:");
		scanf("%d",&slect);
		switch(slect)
		{
		case 1:
			system("cls");
			InitList(&pcb_running);
			if(ff == 0)
				InitList(&process);
            InitList(&pcb_ready);
			InitList(&pcb_finished);
			Process_menu();
			system("pause");
			system("cls");
			break;
		case 2:
			system("cls");
			Memory_menu();
			ff = 1;//ֻ��ʼ��һ��
			system("cls");
			break;
		case 3:
			system("cls");
			File_menu();
			system("cls");
			break;
		case 4:
			flag = 0;
			break;
		default:
			printf("����������������!\n");
			break;
		}
	}
	return 0;
}
